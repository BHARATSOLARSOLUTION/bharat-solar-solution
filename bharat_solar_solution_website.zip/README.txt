BHARAT SOLAR SOLUTION WEBSITE

Files:
- index.html: complete responsive bilingual website (Hindi/English)

FREE PUBLISHING OPTION:
1. Create a GitHub account at https://github.com/
2. Create a new public repository named: bharat-solar-solution
3. Upload index.html to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch; select main and /(root), then Save.
6. GitHub will provide a free website address, usually:
   https://YOUR-GITHUB-USERNAME.github.io/bharat-solar-solution/

The free address is not bharatsolarsolution.in. A custom .in domain normally costs money.
Before publishing, verify vendor registration wording, service claims, phone numbers, addresses,
brand authorization/availability, and any subsidy statements. The page intentionally says
subsidy is subject to current rules and eligibility.
